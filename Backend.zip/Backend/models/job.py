from Backend.db import db

from datetime import datetime

class Job(db.Model):
    __tablename__ = "jobs"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    company = db.Column(db.String(255), nullable=False)
    location = db.Column(db.String(255), nullable=True)
    posting_date = db.Column(db.String(100), nullable=True)
    job_type = db.Column(db.String(50), nullable=True)
    tags = db.Column(db.Text, nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('title', 'company', name='uq_title_company'),
    )

    def __repr__(self):
        return f"<Job {self.title} at {self.company}>"
