from flask import Blueprint, request, jsonify
from Backend.models.job import Job
from Backend.db import db

job_bp = Blueprint('job_bp', __name__)

@job_bp.route('/jobs', methods=['GET'])
def get_jobs():
    jobs = Job.query.all()
    result = []
    for job in jobs:
        result.append({
            'id': job.id,
            'title': job.title,
            'company': job.company,
            'location': job.location,
            'posting_date': job.posting_date,
            'job_type': job.job_type,
            'tags': job.tags
        })
    return jsonify(result)

# New job
@job_bp.route('/jobs', methods=['POST'])
def add_job():
    data = request.get_json()
    new_job = Job(
        title=data.get('title'),
        company=data.get('company'),
        location=data.get('location'),
        posting_date=data.get('posting_date'),
        job_type=data.get('job_type'),
        tags=data.get('tags')
    )
    db.session.add(new_job)
    db.session.commit()
    return jsonify({"message": "Job added successfully."}), 201

# Delete job by ID
@job_bp.route('/jobs/<int:id>', methods=['DELETE'])
def delete_job(id):
    job = Job.query.get(id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    db.session.delete(job)
    db.session.commit()
    return jsonify({'message': 'Job deleted'}), 200

# Update job by ID
@job_bp.route('/jobs/<int:id>', methods=['PUT'])
def update_job(id):
    try:
        print(f" PUT request received for job ID: {id}")
        
        job = Job.query.get(id)
        if not job:
            print(f" Job with ID {id} not found")
            return jsonify({'error': 'Job not found'}), 404

        data = request.get_json()
        print(f" Data received: {data}")
        
        tags_data = data.get('tags', job.tags)
        if isinstance(tags_data, list):
            tags_string = ', '.join(tags_data)
        else:
            tags_string = tags_data
        
        job.title = data.get('title', job.title)
        job.company = data.get('company', job.company)
        job.location = data.get('location', job.location)
        job.posting_date = data.get('posting_date', job.posting_date)
        job.job_type = data.get('job_type', job.job_type)
        job.tags = tags_string

        db.session.commit()
        print(f" Job {id} updated successfully")
        return jsonify({'message': 'Job updated successfully'}), 200
        
    except Exception as e:
        print(f" Error updating job {id}: {str(e)}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
