from flask import Flask
from flask_cors import CORS
from Backend.db import db
from Backend.routes.job_routes import job_bp

def create_app():
    app = Flask(__name__)
    
    
    from Backend.config import Config
    app.config.from_object(Config)

    
    db.init_app(app)
    CORS(app)

    
    from Backend.routes.job_routes import job_bp
    app.register_blueprint(job_bp)

    
    @app.route("/")
    def index():
        return {"message": "BitBash Job API is running."}

    return app

if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        db.create_all()  
    app.run(debug=True)
