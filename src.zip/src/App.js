import React from 'react';
import Navbar from './Components/Navbar';
import JobList from './Components/JobList';
import './App.css';

function App() {
  return (
    <>
      <Navbar />
      <JobList />
    </>
  );
}

export default App;