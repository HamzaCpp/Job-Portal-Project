import React, { useEffect, useState } from 'react';
import axios from 'axios';
import JobCard from './JobCard';
import Pagination from './Pagination';
import PostJobCard from './PostJobCard';
import EditJobModal from './EditJobModal';
import DeleteModal from './DeleteModal';

import './JobList.css';
import './JobCard.css';
import './Pagination.css';
import './PostJobCard.css';
import './EditJobModal.css';

// Function to extract country name from location (removes emojis)
const extractCountryName = (location) => {
  // Remove emojis and extra spaces
  return location.replace(/[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu, '').trim();
};

// Inline Sidebar component
const Sidebar = ({
  countries = [],
  companies = [],
  selectedCountry,
  selectedCompany,
  sortOption,
  setSelectedCountry,
  setSelectedCompany,
  setSortOption,
}) => {
  return (
    <aside className="sidebar">
      <h5>Filters</h5>

      {/* Country Filter */}
      <label>Location:</label>
      <select
        className="form-control mb-3"
        value={selectedCountry}
        onChange={(e) => setSelectedCountry(e.target.value)}
      >
        <option value="">All Locations</option>
        {countries.map((country, index) => (
          <option key={index} value={country}>
            {extractCountryName(country)}
          </option>
        ))}
      </select>

      {/* Company Filter */}
      <label>Company:</label>
      <select
        className="form-control mb-3"
        value={selectedCompany}
        onChange={(e) => setSelectedCompany(e.target.value)}
      >
        <option value="">All Companies</option>
        {companies.map((company, index) => (
          <option key={index} value={company}>
            {company}
          </option>
        ))}
      </select>

      {/* Sort Options */}
      <label>Sort by:</label>
      <select
        className="form-control"
        value={sortOption}
        onChange={(e) => setSortOption(e.target.value)}
      >
        <option value="">Default</option>
        <option value="title">Job Title (A-Z)</option>
        <option value="company">Company (A-Z)</option>
      </select>
    </aside>
  );
};

const JobList = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [editJob, setEditJob] = useState(null);
  const [deleteJobId, setDeleteJobId] = useState(null);

  // Filter & Sort states
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedCompany, setSelectedCompany] = useState('');
  const [sortOption, setSortOption] = useState('');

  const jobsPerPage = 10;

  const fetchJobs = async () => {
    try {
      const response = await axios.get('http://localhost:5000/jobs');
      setJobs(response.data.reverse());
      setLoading(false);
    } catch (error) {
      console.error('Error fetching jobs:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/jobs/${id}`);
      setDeleteJobId(null);
      fetchJobs();
    } catch (error) {
      console.error('Error deleting job:', error);
    }
  };

  const handleUpdate = async (id, updatedJob) => {
    try {
      await axios.put(`http://localhost:5000/jobs/${id}`, updatedJob);
      setEditJob(null);
      fetchJobs();
    } catch (error) {
      console.error('Error updating job:', error);
    }
  };

  // Filtering & Sorting Logic
  const filteredJobs = jobs.filter((job) => {
    const matchesCountry = selectedCountry
      ? job.location?.toLowerCase().includes(selectedCountry.toLowerCase())
      : true;
    const matchesCompany = selectedCompany
      ? job.company?.toLowerCase() === selectedCompany.toLowerCase()
      : true;
    return matchesCountry && matchesCompany;
  });

  const sortedJobs = [...filteredJobs].sort((a, b) => {
    if (sortOption === 'title') {
      return a.title.localeCompare(b.title);
    } else if (sortOption === 'company') {
      return a.company.localeCompare(b.company);
    }
    return 0;
  });

  const indexOfLastJob = currentPage * jobsPerPage;
  const indexOfFirstJob = indexOfLastJob - jobsPerPage;
  const currentJobs = sortedJobs.slice(indexOfFirstJob, indexOfLastJob);

  // Get unique values for filters
  const countries = [...new Set(jobs.map((job) => job.location).filter(Boolean))];
  const companies = [...new Set(jobs.map((job) => job.company).filter(Boolean))];

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCountry, selectedCompany, sortOption]);

  return (
    <div className="container">
      <div className="main-layout">
        <Sidebar
          countries={countries}
          companies={companies}
          selectedCountry={selectedCountry}
          setSelectedCountry={setSelectedCountry}
          selectedCompany={selectedCompany}
          setSelectedCompany={setSelectedCompany}
          sortOption={sortOption}
          setSortOption={setSortOption}
        />

        <div className="content-area">
          <PostJobCard onJobPosted={fetchJobs} />

          {loading ? (
            <p>Loading jobs...</p>
          ) : (
            <>
              <div className="jobs-header">
                <h3>Jobs ({sortedJobs.length})</h3>
              </div>

              <div className="job-list-grid">
                {currentJobs.length > 0 ? (
                  currentJobs.map((job) => (
                    <JobCard
                      key={job.id}
                      job={job}
                      onEdit={setEditJob}
                      onDelete={() => setDeleteJobId(job.id)}
                    />
                  ))
                ) : (
                  <div className="no-jobs">
                    <p>No jobs found matching your filters.</p>
                    <p>Try adjusting your filter criteria.</p>
                  </div>
                )}
              </div>

              <Pagination
                totalJobs={sortedJobs.length}
                jobsPerPage={jobsPerPage}
                currentPage={currentPage}
                setCurrentPage={setCurrentPage}
              />
            </>
          )}
        </div>
      </div>

      {editJob && (
        <EditJobModal
          job={editJob}
          onClose={() => setEditJob(null)}
          onUpdate={handleUpdate}
        />
      )}

      {deleteJobId && (
        <DeleteModal
          onClose={() => setDeleteJobId(null)}
          onConfirm={() => handleDelete(deleteJobId)}
        />
      )}
    </div>
  );
};

export default JobList;