import React, { useState } from 'react';
import axios from 'axios';
import './PostJobCard.css';

const PostJobCard = ({ onJobPosted }) => {
  const [formData, setFormData] = useState({
    title: '',
    company: '',
    location: '',
    posting_date: '',
    job_type: '',
    tags: ''
  });

  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};

    // Check if fields are empty
    if (!formData.title.trim()) newErrors.title = 'Job title is required';
    if (!formData.company.trim()) newErrors.company = 'Company name is required';
    if (!formData.location.trim()) newErrors.location = 'Location is required';
    if (!formData.posting_date.trim()) newErrors.posting_date = 'Posting date is required';
    if (!formData.job_type.trim()) newErrors.job_type = 'Job type is required';
    if (!formData.tags.trim()) newErrors.tags = 'Tags are required';

    // Validate title length
    if (formData.title.length > 100) {
      newErrors.title = 'Job title must be less than 100 characters';
    }

    // Validate company name length
    if (formData.company.length > 80) {
      newErrors.company = 'Company name must be less than 80 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    setFormData({
      ...formData,
      [name]: value
    });

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      await axios.post('http://localhost:5000/jobs', formData);
      onJobPosted(); // refresh job list
      setFormData({
        title: '',
        company: '',
        location: '',
        posting_date: '',
        job_type: '',
        tags: ''
      });
      setErrors({});
    } catch (error) {
      console.error('Error posting job:', error);
    }
  };

  return (
    <div className="post-job-card">
      <h2>Post a New Job</h2>
      <form onSubmit={handleSubmit} className="post-job-form">
        <div className="form-row">
          <div className="form-group">
            <input 
              type="text" 
              name="title" 
              value={formData.title} 
              onChange={handleChange} 
              placeholder="Job Title *" 
              maxLength="100"
              className={errors.title ? 'error' : ''}
            />
            {errors.title && <span className="error-message">{errors.title}</span>}
          </div>
          <div className="form-group">
            <input 
              type="text" 
              name="company" 
              value={formData.company} 
              onChange={handleChange} 
              placeholder="Company Name *" 
              maxLength="80"
              className={errors.company ? 'error' : ''}
            />
            {errors.company && <span className="error-message">{errors.company}</span>}
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <input 
              type="text" 
              name="location" 
              value={formData.location} 
              onChange={handleChange} 
              placeholder="Location *" 
              className={errors.location ? 'error' : ''}
            />
            {errors.location && <span className="error-message">{errors.location}</span>}
          </div>
          <div className="form-group">
            <input 
              type="date" 
              name="posting_date" 
              value={formData.posting_date} 
              onChange={handleChange} 
              className={errors.posting_date ? 'error' : ''}
            />
            {errors.posting_date && <span className="error-message">{errors.posting_date}</span>}
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <select 
              name="job_type" 
              value={formData.job_type} 
              onChange={handleChange}
              className={errors.job_type ? 'error' : ''}
            >
              <option value="">Select Job Type *</option>
              <option value="Full-Time">Full-Time</option>
              <option value="Part-Time">Part-Time</option>
              <option value="Contract">Contract</option>
              <option value="Freelance">Freelance</option>
              <option value="Internship">Internship</option>
            </select>
            {errors.job_type && <span className="error-message">{errors.job_type}</span>}
          </div>
          <div className="form-group">
            <input 
              type="text" 
              name="tags" 
              value={formData.tags} 
              onChange={handleChange} 
              placeholder="Tags (comma separated) *" 
              className={errors.tags ? 'error' : ''}
            />
            {errors.tags && <span className="error-message">{errors.tags}</span>}
          </div>
        </div>

        <button type="submit" className="submit-btn">Post Job</button>
      </form>
    </div>
  );
};

export default PostJobCard;