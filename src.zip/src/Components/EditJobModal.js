import React, { useState, useEffect } from "react";
import "./EditJobModal.css";

const EditJobModal = ({ job, onClose, onUpdate }) => {
  const [formData, setFormData] = useState({
    title: "",
    company: "",
    location: "",
    posting_date: "",
    job_type: "",
    tags: "",
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (job) {
      setFormData({
        title: job.title || "",
        company: job.company || "",
        location: job.location || "",
        posting_date: job.posting_date || "",
        job_type: job.job_type || "",
        tags: Array.isArray(job.tags) ? job.tags.join(", ") : job.tags || "",
      });
    }
  }, [job]);

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.title.trim()) newErrors.title = 'Title is required';
    if (!formData.company.trim()) newErrors.company = 'Company is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    
    // Clear error 
    if (errors[name]) {
      setErrors({ ...errors, [name]: "" });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      console.log("Form validation failed");
      return;
    }

    if (isSubmitting) return;

    setIsSubmitting(true);
    
    try {
      const updatedJob = {
        ...formData,
        tags: formData.tags.split(",").map((tag) => tag.trim()).filter(tag => tag),
      };
      
      console.log("Submitting update for job ID:", job.id);
      console.log("Updated job data:", updatedJob);
      
      await onUpdate(job.id, updatedJob);
      
      console.log("Update completed successfully");
      onClose();
      
    } catch (error) {
      console.error("Error updating job:", error);
      alert("Failed to update job. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    job && (
      <div className="modal-overlay">
        <div className="modal-content">
          <h2>Edit Job</h2>
          <form onSubmit={handleSubmit} className="modal-form">
            <div className="form-row">
              <div className="form-group">
                <input 
                  name="title" 
                  placeholder="Title *" 
                  value={formData.title} 
                  onChange={handleChange}
                  className={errors.title ? 'error' : ''}
                />
                {errors.title && <span className="error-message">{errors.title}</span>}
              </div>
              <div className="form-group">
                <input 
                  name="company" 
                  placeholder="Company *" 
                  value={formData.company} 
                  onChange={handleChange}
                  className={errors.company ? 'error' : ''}
                />
                {errors.company && <span className="error-message">{errors.company}</span>}
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <input 
                  name="location" 
                  placeholder="Location" 
                  value={formData.location} 
                  onChange={handleChange} 
                />
              </div>
              <div className="form-group">
                <input
                  type="date"
                  name="posting_date"
                  value={formData.posting_date}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <select name="job_type" value={formData.job_type} onChange={handleChange}>
                  <option value="">Select Job Type</option>
                  <option value="Full-Time">Full-Time</option>
                  <option value="Part-Time">Part-Time</option>
                  <option value="Contract">Contract</option>
                  <option value="Internship">Internship</option>
                </select>
              </div>
              <div className="form-group">
                <input
                  name="tags"
                  placeholder="Tags (comma separated)"
                  value={formData.tags}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="modal-buttons">
              <button type="button" className="cancel-btn" onClick={onClose}>
                Cancel
              </button>
              <button 
                type="submit" 
                className="update-btn" 
                disabled={isSubmitting}
              >
                {isSubmitting ? "Updating..." : "Update"}
              </button>
            </div>
          </form>
        </div>
      </div>
    )
  );
};

export default EditJobModal;