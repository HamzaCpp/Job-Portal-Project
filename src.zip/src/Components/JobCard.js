import React from "react";
import "./JobCard.css";

const JobCard = ({ job, onEdit, onDelete }) => {
  const tags = Array.isArray(job.tags)
    ? job.tags
    : typeof job.tags === "string"
    ? job.tags.split(",").map((t) => t.trim())
    : [];

  return (
    <div className="job-card">
      <div className="job-header">
        <div className="job-main-info">
          <h3 className="job-title">{job.title}</h3>
          <p className="job-company">{job.company}</p>
          <div className="job-location-info">
            {job.location && <span className="location-badge">{job.location}</span>}
            {job.job_type && <span className="job-type-badge">{job.job_type}</span>}
            {job.posting_date && <span className="date-badge">{job.posting_date}</span>}
          </div>
        </div>
        
        <div className="job-right">
          {tags.length > 0 && (
            <div className="tag-container">
              {tags.slice(0, 4).map((tag, index) => (
                <span key={index} className="job-tag">
                  {tag}
                </span>
              ))}
              {tags.length > 4 && (
                <span className="more-tags">+{tags.length - 4}</span>
              )}
            </div>
          )}
          
          <div className="job-actions">
            <button className="edit-btn" onClick={() => onEdit(job)}>Edit</button>
            <button className="delete-btn" onClick={() => onDelete(job.id)}>Delete</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobCard;