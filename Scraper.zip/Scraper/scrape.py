import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException
from webdriver_manager.chrome import ChromeDriverManager

from Backend.app import create_app
from Backend.db import db
from Backend.models.job import Job
import time

app = create_app()

def run_scraper():
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.get("https://www.actuarylist.com/")
    time.sleep(2)

    scraped = 0
    max_jobs = 100

    while scraped < max_jobs:
        job_cards = driver.find_elements(By.CLASS_NAME, "Job_job-card__YgDAV")

        for card in job_cards:
            if scraped >= max_jobs:
                break
            try:
                title = card.find_element(By.CLASS_NAME, "Job_job-card__position__ic1rc").text
                company = card.find_element(By.CLASS_NAME, "Job_job-card__company__7T9qY").text
                location = card.find_element(By.CLASS_NAME, "Job_job-card__locations__x1exr").text
                posting_date = card.find_element(By.CLASS_NAME, "Job_job-card__posted-on__NCZaJ").text

                job_type = "Full-Time"
                tags_elements = card.find_elements(By.CLASS_NAME, "Job_job-card__location__bq7jX")
                tags = [tag.text for tag in tags_elements if tag.text.strip()]
                if any("Intern" in tag for tag in tags):
                    job_type = "Intern"
                elif any("Part-Time" in tag for tag in tags):
                    job_type = "Part-Time"

                # Skip if job already exists
                exists = Job.query.filter_by(title=title, company=company).first()
                if exists:
                    continue

                job = Job(
                    title=title,
                    company=company,
                    location=location,
                    posting_date=posting_date,
                    job_type=job_type,
                    tags=", ".join(tags)
                )
                db.session.add(job)
                scraped += 1
                print(f"{scraped}) {title} | {company} | {location} | {posting_date} | {job_type} | {tags}")

            except Exception as e:
                print("Error scraping card:", e)

        # Click the "Next" button to go to the next page
        try:
            next_btn = driver.find_element(By.XPATH, "//button[contains(text(), 'Next')]")
            driver.execute_script("arguments[0].click();", next_btn)
            time.sleep(2)
        except (NoSuchElementException, ElementClickInterceptedException):
            print("No more pages or failed to click next.")
            break

    db.session.commit()
    driver.quit()
    print(f"✅ Scraped and saved {scraped} new job listings.")

with app.app_context():
    db.create_all()
    run_scraper()
